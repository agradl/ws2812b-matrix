Util = {};

Util.addGrid = function(rootEl, xSize, ySize) {
  var gridEl = $("<div></div>");
  for (var y = 0; y < ySize; y++) {
    var row = $('<div class="row"></div>');
    gridEl.append(row);
    for (var x = 0; x < xSize; x++) {
      var cell = $('<div class="cell"></div>');
      cell.data({ x: x, y: y });
      row.append(cell);
    }
  }
  rootEl.append(gridEl);
};

function getLEDIndex(x, y) {
  if (y % 2 === 1) {
    //odd
    return 16 * y + (15 - x);
  } else {
    return 16 * y + x;
  }
}

Util.getLEDIndex = getLEDIndex;

Util.setLED = function setLED(x, y, rgb) {
  if (x < 0 || y < 0 || x > 15 || y > 15) {
    return false;
  }
  leds[getLEDIndex(x, y)](rgb);
  return true;
};

Util.init = function(setup, loop) {
  setup();
  setInterval(loop, 10);
};

Util.getLEDIndex = function getLEDIndex(x, y) {
  if (y % 2 === 1) {
    //odd
    return 16 * y + (15 - x);
  } else {
    return 16 * y + x;
  }
};

Util.setLED = function setLED(x, y, rgb) {
  if (x < 0 || y < 0 || x > 15 || y > 15) {
    return false;
  }
  leds[getLEDIndex(x, y)](rgb);
  return true;
};

Util.clearLEDs = function() {
  FastLED.showColor('');
};

Util.RGBToHex = function(r, g, b) {
  r = r.toString(16);
  g = g.toString(16);
  b = b.toString(16);

  if (r.length == 1) r = "0" + r;
  if (g.length == 1) g = "0" + g;
  if (b.length == 1) b = "0" + b;

  return "#" + r + g + b;
};

Util.hexToRGB = function(h) {
  let r = 0,
    g = 0,
    b = 0;

  // 3 digits
  if (h.length == 4) {
    r = "0x" + h[1] + h[1];
    g = "0x" + h[2] + h[2];
    b = "0x" + h[3] + h[3];

    // 6 digits
  } else if (h.length == 7) {
    r = "0x" + h[1] + h[2];
    g = "0x" + h[3] + h[4];
    b = "0x" + h[5] + h[6];
  }

  return "rgb(" + +r + ", " + +g + ", " + +b + ")";
};

Util.RGBStringToHex = function(rgb) {
  // Choose correct separator
  let sep = rgb.indexOf(",") > -1 ? "," : " ";
  // Turn "rgb(r,g,b)" into [r,g,b]
  rgb = rgb
    .substr(4)
    .split(")")[0]
    .split(sep);

  let r = (+rgb[0]).toString(16),
    g = (+rgb[1]).toString(16),
    b = (+rgb[2]).toString(16);

  if (r.length == 1) r = "0" + r;
  if (g.length == 1) g = "0" + g;
  if (b.length == 1) b = "0" + b;

  return "#" + r + g + b;
};

Util.copyToClipboard = function(str) {
  const el = document.createElement("textarea");
  el.value = str;
  el.setAttribute("readonly", "");
  el.style.position = "absolute";
  el.style.left = "-9999px";
  document.body.appendChild(el);
  const selected =
    document.getSelection().rangeCount > 0
      ? document.getSelection().getRangeAt(0)
      : false;
  el.select();
  document.execCommand("copy");
  document.body.removeChild(el);
  if (selected) {
    document.getSelection().removeAllRanges();
    document.getSelection().addRange(selected);
  }
};
